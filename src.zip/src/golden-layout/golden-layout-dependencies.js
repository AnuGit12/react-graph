import $ from "jquery";


window.$ = $;
window.jQuery = $;
window.jquery = $;

